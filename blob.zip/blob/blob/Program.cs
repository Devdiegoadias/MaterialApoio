﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using System;
using System.IO;
using Azure.Identity;


var blobServiceClient = new BlobServiceClient(
        new Uri("https://storageazureetapa3.blob.core.windows.net"),
        new DefaultAzureCredential());


string containerName = "imagensaulainfnet";


BlobContainerClient containerClient = await blobServiceClient.CreateBlobContainerAsync(containerName);


string localPath = "data";
Directory.CreateDirectory(localPath);
string fileName = "quickstart" + Guid.NewGuid().ToString() + ".txt";
string localFilePath = Path.Combine(localPath, fileName);


await File.WriteAllTextAsync(localFilePath, "Hello, World!");


BlobClient blobClient = containerClient.GetBlobClient(fileName);

Console.WriteLine("Uploading to Blob storage as blob:\n\t {0}\n", blobClient.Uri);


await blobClient.UploadAsync(localFilePath, true);

await foreach (BlobItem blobItem in containerClient.GetBlobsAsync())
{
    Console.WriteLine("\t" + blobItem.Name);
}


string downloadFilePath = localFilePath.Replace(".txt", "DOWNLOADED.txt");

Console.WriteLine("\nDownloading blob to\n\t{0}\n", downloadFilePath);


await blobClient.DownloadToAsync(downloadFilePath);


Console.Write("Press any key to begin clean up");
Console.ReadLine();

Console.WriteLine("Deleting blob container...");
await containerClient.DeleteAsync();

Console.WriteLine("Deleting the local source and downloaded files...");
File.Delete(localFilePath);
File.Delete(downloadFilePath);

Console.WriteLine("Done");