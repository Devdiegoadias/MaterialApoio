﻿using Microsoft.Data.SqlClient;

namespace aulainfnet
{

    class Program
    {
        static void Main(string[] args)
        {
            try
            {

                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

                builder.DataSource = "aula0203databaseserver.database.windows.net";
                builder.InitialCatalog = "aula0203DataBase";
                builder.UserID = "AdminServer";
                builder.Password = "AulaInfnet123";


                //Inserindo dados via command com TEXTO
                using (SqlConnection conn = new SqlConnection(builder.ToString()))
                {
                    conn.Open();

                    SqlCommand cmd = new SqlCommand
                    {
                        CommandType = System.Data.CommandType.Text,
                        CommandText = "INSERT INTO T_MARCA (Descricao,Tipo) VALUES ('TENIS ADIDAS','T')",
                        Connection = conn
                    };

                    cmd.ExecuteNonQuery();



                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = "INSERT INTO T_PRODUTO (Nome,Marca_id) VALUES ('PRODUTO TENIS ADIDAS',1)";
                    cmd.Connection = conn;

                    cmd.ExecuteNonQuery();
                }

                using (SqlConnection conn = new SqlConnection(builder.ToString()))
                {
                    Console.WriteLine("\nUsando SQL Query");

                    conn.Open();

                    string sql = "select nome, preco from t_produto";

                    using (SqlCommand command = new SqlCommand(sql, conn))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Console.WriteLine("Nome :{0} - Preco:{1}",reader.GetString(0),reader.GetSqlMoney(1));
                        
                            }
                        }
                    }


                }

                using (SqlConnection conn = new SqlConnection(builder.ToString()))
                {
                    Console.WriteLine("\nUsando PROCEDURE");

                    conn.Open();                    

                    using (SqlCommand command = new SqlCommand("P_LISTA_PRODUTOS", conn))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Console.WriteLine("Nome :{0} - Preco:{1}", reader.GetString(0), reader.GetSqlMoney(1));

                            }
                        }
                    }


                }


            }
            catch (SqlException ex)
            {
                Console.WriteLine("ERRO SQL =>>>>>" + ex.Message);
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine("ERRO GENÉRICO =>>>>>>" + ex.Message);
                Console.ReadLine();
            }

        }
    }
}