﻿using Azure.Storage.Queues;
using System.Configuration;
using Azure.Storage.Queues.Models;
using Azure.Communication.Email;
using Azure.Communication.Email.Models;

class ProgramaFila
{
    static void Main(string[] args)
    {
        string connectionString = ConfigurationManager.AppSettings["StorageConnectionString"];

        QueueClient queueClient = new QueueClient(connectionString, "filaaula2802");

        
        queueClient.CreateIfNotExists();

        queueClient.SendMessage("Can you hear me? 1");
        queueClient.SendMessage("Can you hear me? 2");
        queueClient.SendMessage("Can you hear me? 3");
        queueClient.SendMessage("Can you hear me? 4");
        

        //Retorna o primeiro a  entrar!
        var item = queueClient.PeekMessage();

        string conteudoFila = item.Value.Body.ToString();

        //Lista a primeira mensagem!
        QueueMessage[] mensagens = queueClient.ReceiveMessages();


        //Atualizar a primeira mensagem (fila) e 'sumir' com ela por 30 segundos.
        //queueClient.UpdateMessage(mensagens[0].MessageId, mensagens[0].PopReceipt,
        //    "ATUALIZADO", TimeSpan.FromSeconds(30));

        //ENVIANDO EMAIL
        connectionString = ConfigurationManager.AppSettings["EmailConnectionString"];

        var emailClient = new EmailClient(connectionString);

        EmailContent emailContent = new EmailContent("TESTE EMAIL AULA FILA 2802");

        emailContent.PlainText = "ENVIADO PELO AZURE O RESULTADO DA FILA: " + conteudoFila;

        List<EmailAddress> lstEmail = new List<EmailAddress> { new EmailAddress("diego.dias@prof.infnet.edu.br") };

        EmailRecipients emailRecipients = new EmailRecipients(lstEmail);

        EmailMessage emailMessage =
            new EmailMessage("NaoResponder@ec062460-cd5c-4ec3-a287-befbcf91cd3a.azurecomm.net", 
            emailContent, emailRecipients);

        var retorno = emailClient.Send(emailMessage, CancellationToken.None);

        
        Console.ReadLine();
    }

}