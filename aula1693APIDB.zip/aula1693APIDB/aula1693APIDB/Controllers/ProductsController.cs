﻿using aula1693APIDB.Models;
using Microsoft.AspNetCore.Mvc;

namespace aula1693APIDB.Controllers
{
    [Route ("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly AdventureWorksLt2019Context _context;

        public ProductsController(AdventureWorksLt2019Context context)
        {
            _context = context;
        }

        [HttpGet("GetAllProducts")]
        public List<Product> GetAllProducts()
        {
            return _context.Products.ToList();
        }

        
    }
}
